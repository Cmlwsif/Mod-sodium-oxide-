package com.example.myoptimizationmod;

import net.fabricmc.api.ClientModInitializer;

public class MyOptimizationModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        System.out.println("Sodium Oxide Mod initialized!");
    }
}
