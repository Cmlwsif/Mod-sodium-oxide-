# Sodium Oxide Mod  
Optimization mod for Minecraft 1.16.5 using Sodium.  
## Installation  
- Place the JAR file in the mods folder.  
## Features  
- Chunk optimization  
- Improved rendering  
## License  
MIT
